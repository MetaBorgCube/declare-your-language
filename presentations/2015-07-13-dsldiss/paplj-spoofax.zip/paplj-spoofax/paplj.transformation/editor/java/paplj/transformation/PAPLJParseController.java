package paplj.transformation;

public class PAPLJParseController extends PAPLJParseControllerGenerated 
{ }