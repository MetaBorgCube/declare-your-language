package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_initObject__Arrow extends AbstractNode implements IMatchableNode
{ 
  public R_default_Obj exec_default(com.github.krukow.clj_ds.PersistentMap<String, A_V> _1, com.github.krukow.clj_ds.PersistentMap<String, A_Class> _2, com.github.krukow.clj_ds.PersistentMap<Integer, A_V> _3)
  { 
    this.specializeChildren(0);
    throw new InterpreterException("Rule failure", "default", this);
  }
}