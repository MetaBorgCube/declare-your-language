package paplj.syntax;

public class PAPLJParseController extends PAPLJParseControllerGenerated 
{ }