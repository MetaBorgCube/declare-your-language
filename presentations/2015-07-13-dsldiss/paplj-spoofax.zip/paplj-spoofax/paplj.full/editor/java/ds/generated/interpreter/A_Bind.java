package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_Bind extends AbstractNode implements IMatchableNode
{ }