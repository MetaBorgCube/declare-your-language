package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_Obj extends AbstractNode implements IMatchableNode
{ }