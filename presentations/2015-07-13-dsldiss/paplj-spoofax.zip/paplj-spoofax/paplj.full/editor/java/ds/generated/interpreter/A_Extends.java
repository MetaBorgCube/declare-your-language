package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_Extends extends AbstractNode implements IMatchableNode
{ }