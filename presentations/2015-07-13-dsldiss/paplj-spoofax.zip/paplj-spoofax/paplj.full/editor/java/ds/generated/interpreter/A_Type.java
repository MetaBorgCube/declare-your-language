package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_Type extends AbstractNode implements IMatchableNode
{ }