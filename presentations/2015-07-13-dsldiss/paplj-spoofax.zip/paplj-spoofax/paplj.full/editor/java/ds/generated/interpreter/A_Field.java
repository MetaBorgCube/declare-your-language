package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_Field extends AbstractNode implements IMatchableNode
{ }