package ds.generated.interpreter;

import org.metaborg.meta.interpreter.framework.*;

public abstract class A_V extends AbstractNode implements IMatchableNode
{ }