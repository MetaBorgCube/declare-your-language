package paplj.full;

public class PAPLJParseController extends PAPLJParseControllerGenerated 
{ }