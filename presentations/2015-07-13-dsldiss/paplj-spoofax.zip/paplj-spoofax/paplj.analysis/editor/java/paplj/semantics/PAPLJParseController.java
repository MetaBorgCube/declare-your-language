package paplj.semantics;

public class PAPLJParseController extends PAPLJParseControllerGenerated 
{ }