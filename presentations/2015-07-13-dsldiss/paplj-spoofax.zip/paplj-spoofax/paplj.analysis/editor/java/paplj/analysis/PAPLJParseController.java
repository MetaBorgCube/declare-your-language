package paplj.analysis;

public class PAPLJParseController extends PAPLJParseControllerGenerated 
{ }